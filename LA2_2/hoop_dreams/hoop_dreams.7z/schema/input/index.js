const pickupGameInput = require('./PickupGameInput');
const playerInput = require('./PlayerInput');
const signupPlayerInput = require('./SignupPlayerInput');

module.exports = `
    ${pickupGameInput}
    ${playerInput}
    ${signupPlayerInput}
`