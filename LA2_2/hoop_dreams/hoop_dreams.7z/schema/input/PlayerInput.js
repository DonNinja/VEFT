module.exports = `
    input PlayerInput {
        name: String!
    }
`