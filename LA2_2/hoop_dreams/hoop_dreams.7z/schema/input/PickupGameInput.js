module.exports = `
    input PickupGameInput {
        start: Moment!
        end: Moment!
        basketballFieldId: String!
        hostId: String!
    }
`