module.exports = `
  scalar Moment
`;