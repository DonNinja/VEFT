const momentScalar = require("./momentScalar");

module.exports = `
    ${momentScalar}
`