const BasketballFieldStatus = require('./BasketballFieldStatus');

module.exports = `
    ${BasketballFieldStatus}
`;
